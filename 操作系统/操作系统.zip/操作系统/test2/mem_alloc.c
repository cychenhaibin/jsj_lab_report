#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A simple memory allocation module");
MODULE_VERSION("0.01");
static void *kmalloc_1kb, *kmalloc_8kb, *vmalloc_8kb, *vmalloc_1mb, *vmalloc_64mb;
static int __init mem_alloc_init(void) {
    printk(KERN_INFO "Allocating memory...\n");
    // 使用 kmalloc 分配 1KB 和 8KB 的内存
    kmalloc_1kb = kmalloc(1024, GFP_KERNEL);
    kmalloc_8kb = kmalloc(8192, GFP_KERNEL);
    // 使用 vmalloc 分配 8KB、1MB、64MB 的内存
    vmalloc_8kb = vmalloc(8192);
    vmalloc_1mb = vmalloc(1024 * 1024);
    vmalloc_64mb = vmalloc(64 * 1024 * 1024);
    // 打印指针地址
    printk(KERN_INFO "kmalloc 1KB: %p\n", kmalloc_1kb);
    printk(KERN_INFO "kmalloc 8KB: %p\n", kmalloc_8kb);
    printk(KERN_INFO "vmalloc 8KB: %p\n", vmalloc_8kb);
    printk(KERN_INFO "vmalloc 1MB: %p\n", vmalloc_1mb);
    printk(KERN_INFO "vmalloc 64MB: %p\n", vmalloc_64mb);
    return 0;
}
static void __exit mem_alloc_exit(void) {
    printk(KERN_INFO "Freeing memory...\n");
    // 释放内存
    kfree(kmalloc_1kb);
    kfree(kmalloc_8kb);
    vfree(vmalloc_8kb);
    vfree(vmalloc_1mb);
    vfree(vmalloc_64mb);
}
module_init(mem_alloc_init);
module_exit(mem_alloc_exit);
