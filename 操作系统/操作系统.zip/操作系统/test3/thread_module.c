#include <linux/module.h>      // 必须的，支持模块操作
#include <linux/kernel.h>      // 必须的，支持内核功能
#include <linux/init.h>        // 必须的，支持模块初始化和清理
#include <linux/kthread.h>     // 支持内核线程

MODULE_LICENSE("GPL");  // 模块许可证
MODULE_AUTHOR("Your Name");  // 模块作者
MODULE_DESCRIPTION("A simple kernel thread module");  // 模块描述
MODULE_VERSION("0.01");  // 模块版本

static struct task_struct *kthread_task;  // 内核线程任务结构

static int thread_func(void *data) {
    while (!kthread_should_stop()) {
        printk(KERN_INFO "Kernel thread is running\n");
        schedule();  // 让出CPU，内核线程休眠
    }
    return 0;
}

static int __init thread_module_init(void) {
    kthread_task = kthread_run(thread_func, NULL, "my_kernel_thread");
    if (IS_ERR(kthread_task)) {
        printk(KERN_ALERT "Failed to create kernel thread\n");
        return PTR_ERR(kthread_task);
    }
    return 0;
}

static void __exit thread_module_exit(void) {
    kthread_stop(kthread_task);
}

module_init(thread_module_init);
module_exit(thread_module_exit);
