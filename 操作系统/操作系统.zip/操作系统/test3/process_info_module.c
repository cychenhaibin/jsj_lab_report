#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched/signal.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A module to print running process PID and names");
MODULE_VERSION("0.01");

static int __init process_info_init(void) {
    struct task_struct *task;

    printk(KERN_INFO "Running processes:\n");
    for_each_process(task) {
        // 检查进程是否处于TASK_RUNNING状态
        if (task->exit_state == TASK_RUNNING) {
            printk(KERN_INFO "PID: %d, Name: %s\n", task->pid, task->comm);
        }
    }
    return 0;
}

static void __exit process_info_exit(void) {
    printk(KERN_INFO "Process info module exited\n");
}

module_init(process_info_init);
module_exit(process_info_exit);
