#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#define PORT 40001
#define BUF_SIZE 1024
int main(void)
{
    int sock_fd;
    char buffer[BUF_SIZE];
    int size;
    int len;
    struct sockaddr_in server_addr;
    // 创建socket
    if(-1 == (sock_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))) {
        printf("Failed to create a socket!\n");
        return 0;
    }
    // 服务器信息
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    len = sizeof(server_addr);
    // 从stdin读取并发送到服务器
    while(1) {
        printf("Please enter the content to be sent: ");
        fgets(buffer, BUF_SIZE, stdin); // 使用fgets以包含空格
        // 发送数据
        sendto(sock_fd, buffer, strlen(buffer), 0, (struct sockaddr*)&server_addr, len);
        // 清空buffer
        bzero(buffer, BUF_SIZE);
    }
    close(sock_fd);
    return 0;
}
