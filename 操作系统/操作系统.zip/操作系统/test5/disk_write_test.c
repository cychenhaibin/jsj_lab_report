#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/ktime.h>
#define buf_size 1024
#define write_times 524288
MODULE_LICENSE("GPL");
static int __init write_disk_init(void) {
    struct file *fp_write;
    char *buf;
    loff_t pos = 0;
    int i;
    ssize_t ret;
    ktime_t start, end;
    unsigned long long write_time_ns;
    buf = kmalloc(buf_size, GFP_KERNEL);
    if (!buf) {
        printk(KERN_ERR "Failed to allocate memory\n");
        return -ENOMEM;
    }
    for (i = 0; i < buf_size; i++) {
        buf[i] = '0' + (i % 10); 
    }
    fp_write = filp_open("/home/tmp_file", O_RDWR | O_CREAT, 0644);
    if (IS_ERR(fp_write)) {
        printk(KERN_ERR "Failed to open file\n");
        kfree(buf);
        return PTR_ERR(fp_write);
    }
    start = ktime_get();
    for (i = 0; i < write_times; i++) {
        ret = kernel_write(fp_write, buf, buf_size, &pos);
        if (ret != buf_size) {
            printk(KERN_ERR "Write error or short write, ret: %zd\n", ret);
            filp_close(fp_write, NULL);
            kfree(buf);
            return -EIO;
        }
    }
    end = ktime_get();
    filp_close(fp_write, NULL);
    kfree(buf);
    write_time_ns = ktime_to_ns(ktime_sub(end, start));
    printk(KERN_ALERT "Writing to file costs %llu us\n", write_time_ns / 1000);
    printk(KERN_INFO "Writing speed is %llu M/s\n", (buf_size * write_times * 1000000000ULL) / write_time_ns);
    return 0;
}
static void __exit write_disk_exit(void) {
    printk(KERN_INFO "Exit write_to_disk module\n");
}
module_init(write_disk_init);
module_exit(write_disk_exit);
