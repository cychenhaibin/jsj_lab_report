#include <linux/module.h>
#include <linux/fs.h>
#include <linux/ktime.h>

#define buf_size 1024
#define read_times 524288

MODULE_LICENSE("GPL");

static int __init read_disk_init(void) {
    struct file *fp_read;
    char buf[buf_size];
    int i;
    unsigned long long read_start_time_ns, read_end_time_ns;
    unsigned long long read_time_us;
    loff_t pos;
    ssize_t read_bytes;
    printk("Start read_from_disk module...\n");

    fp_read = filp_open("/home/tmp_file", O_RDONLY, 0);
    if (IS_ERR(fp_read)) {
        printk("Failed to open file...\n");
        return PTR_ERR(fp_read);
    }

    pos = 0;
    read_start_time_ns = ktime_get_ns();

    for (i = 0; i < read_times; i++) {
        read_bytes = kernel_read(fp_read, buf, buf_size, &pos);
        if (read_bytes != buf_size) {
            printk(KERN_WARNING "Read size does not match expected size.\n");
            filp_close(fp_read, NULL);
            return -EIO;
        }
    }

    read_end_time_ns = ktime_get_ns();
    filp_close(fp_read, NULL);

    read_time_us = (read_end_time_ns - read_start_time_ns) / 1000; // Convert to microseconds
    printk(KERN_ALERT "Reading from file costs %llu us\n", read_time_us);

    // 使用 long long 类型避免整数溢出
    unsigned long long speed = (unsigned long long)buf_size * read_times * 1000 / read_time_us;
    printk("Reading speed is %llu M/s\n", speed);

    return 0;
}

static void __exit read_disk_exit(void) {
    printk("Exit read_from_disk module...\n");
}

module_init(read_disk_init);
module_exit(read_disk_exit);
