#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void sigint_handler(int sig) {
    printf("Caught signal %d\n", sig);
}

void sigtstp_handler(int sig) {
    printf("Caught signal %d\n", sig);
}

void sigquit_handler(int sig) {
    printf("Caught signal %d\n", sig);
}

int main() {
    signal(SIGINT, sigint_handler);  // Ctrl+C
    signal(SIGTSTP, sigtstp_handler); // Ctrl+Z
    signal(SIGQUIT, sigquit_handler); // Ctrl+\

    while(1) {
        sleep(1);
    }
    return 0;
}
