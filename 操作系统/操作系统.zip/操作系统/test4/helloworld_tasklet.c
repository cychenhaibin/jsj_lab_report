#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/interrupt.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A simple helloworld tasklet module");
MODULE_VERSION("0.01");

static void helloworld_tasklet(unsigned long data) {
    printk(KERN_INFO "Hello, world!\n");
}

static struct tasklet_struct helloworld_tasklet_handle = {
    .func = helloworld_tasklet,
};

static int __init helloworld_init(void) {
    tasklet_schedule(&helloworld_tasklet_handle);
    return 0;
}

static void __exit helloworld_exit(void) {
    printk(KERN_INFO "Goodbye, world!\n");
}

module_init(helloworld_init);
module_exit(helloworld_exit);
