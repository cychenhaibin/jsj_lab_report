#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/workqueue.h>
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A simple helloworld workqueue module");
MODULE_VERSION("0.01");
static void helloworld_work_handler(struct work_struct *work);
static struct workqueue_struct *my_wq;
static DECLARE_DELAYED_WORK(my_work, helloworld_work_handler);
static void helloworld_work_handler(struct work_struct *work) {
    printk(KERN_INFO "Hello, world!\n");
    schedule_delayed_work(&my_work, HZ); // 每秒执行一次
}
static int __init helloworld_init(void) {
    my_wq = create_workqueue("my_wq");
    if (!my_wq) {
        printk(KERN_ERR "Failed to create workqueue\n");
        return -ENOMEM;
    }
    schedule_delayed_work(&my_work, HZ); 
    return 0;
}
static void __exit helloworld_exit(void) {
    cancel_delayed_work_sync(&my_work);
    destroy_workqueue(my_wq);
    printk(KERN_INFO "Goodbye, world!\n");
}
module_init(helloworld_init);
module_exit(helloworld_exit);
